# HTFE-tensortrade
###
Tensortrade program used in Huatai Securities, writer: Songhao Li
###
This program originated from open source project Tensortrade(see https://github.com/notadamking/tensortrade)

To use the program, please install all the requirements, substitute tensortrade package with files here, and start the program in MAIN/train_and_evaluate.py

# Objective: 
Modify the tensortrade/tensorforce to meet the needs of future market ananlysis. So that it can simulate short selling, recording transaction, and evaluating the profit reasonably.

The original tensortrade program is aquired 10/29/2019 and may not be updated to the latest version with notadamking's master branch.


# Modification record:

Date 11/24/2019
Position_evaluate.py
Choose positions as actions. Check this file for more info.
-------
Date 11/15/2019
tensortrade_clean
Run programs directly in this directory!
------
Date 11/09/2019
0.1 amount per trad
------
actions/future_action_strategy.py

Date: 11/2/2019

------
Ensure the program can generate buy/sell/hold actions.

Date 11/22 



